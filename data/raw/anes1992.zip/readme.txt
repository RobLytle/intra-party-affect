1) Files contained in the anes_timeseries_1992.zip:

INT1992.CBK    					CODEBOOK INTRODUCTORY MATERIAL
NES1992.CBK    					CODEBOOK VARIABLE DOCUMENTATION
APP1992.CBK    					CODEBOOK APPENDIX MATERIAL
NES1992.TXT					DATA NOTES

anes_timeseries_1992_rawdata.txt		Raw data file

anes_timeseries_1992_sas.zip			SAS syntax files
 anes_timeseries_1992_codelabelsassign.sas
 anes_timeseries_1992_columns.sas
 anes_timeseries_1992_codelabelsdefine.sas
 anes_timeseries_1992_missingdata.sas
 anes_timeseries_1992_run.sas
 anes_timeseries_1992_varlabels.sas
 
anes_timeseries_1992_spss.zip			SPSS syntax files
 anes_timeseries_1992_codelabelsassign.sps
 anes_timeseries_1992_columns.sps
 anes_timeseries_1992_missingdata.sps
 anes_timeseries_1992_run.sps
 anes_timeseries_1992_varlabels.sps
 
anes_timeseries_1992_stata.zip			Stata syntax files
 anes_timeseries_1992_codelabelsassign.do
 anes_timeseries_1992_columns.dct
 anes_timeseries_1992_codelabelsdefine.do
 anes_timeseries_1992_missingdata.do
 anes_timeseries_1992_run.do
 anes_timeseries_1992_varlabels.do 


_codelabelsassign = code labels
_columns = columns 
_codelabelsdefine = formats
_missingdata = missing data
_varlabels = variable labels
_run = run file



2) NOTE ON VARIABLE NAMING:

The variable name references used in NES Study codebooks do not include 
the "V" prefix found in all variable names used within the released 
SAS and SPSS data definition files (.sas and .sps files).

For example, "VAR 920001" and "VAR VERSION" in Study codebooks refer to
V920001 and VVERSION in the study data definition files.


3) SPECIAL NOTE ON COLUMN LOCATIONS:

Some numeric variables use coding schemes that allow for code values
having a varying number of digits. In such instances, the number
of columns corresponding to the variable in the data file [.dat file] 
and in the column specifications  will be the width of the maximum value
occurring in the actual data, rather than the maximum width allowable
by the coding scheme.  For example, if codes 01-12 are allowed for a
numeric variable but all values in the data are less than 10, then the
number of columns corresponding to the variable within the ASCII data 
file will be 1.                                                                                                                              


4) Instructions for using SAS, SPSS, and Stata syntax files

The following will allow users to create SAS, SPSS, or Stata datasets using the syntax
files available from the ANES website: First, move the raw data file and all syntax files
to one directory (e.g. 'C:\anes\anes1992\011992'). Second, edit the 'run' files to
include the pathname to the directory where the files reside. The pathname must be added 
to each line that references the raw data file, any of the input syntax files, and the
output file statements (SPSS and Stata). In the SAS 'run' file, the pathname must also be added
to the libname statement. In the case of Stata, in addition to adding pathnames to the 'run'
file, users will need to add the pathname to the first line of the dictionary file (.dct) 
where the raw data file is referenced. Third, execute the edited 'run' file which will 
create a SAS, SPSS, or Stata data files in the directory previously specified by the user.
Missing data statements are, by default, commented out in the 'run' file. Users may restore
them by removing the asterisk (*) at the start of the relevant line.


